package com.example.doclink

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AdminAppointmentsFragment : Fragment() {

    private lateinit var adapter: AdminAppointmentAdapter
    private lateinit var rvAppointments: RecyclerView
    private lateinit var layoutEmptyAppointments: LinearLayout
    private val appointmentList = mutableListOf<AppointmentItem>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_appointments, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvAppointments = view.findViewById(R.id.rvAppointments)
        layoutEmptyAppointments = view.findViewById(R.id.layoutEmptyAppointments)

        setupRecyclerView()
        observeLiveAppointments()
    }

    override fun onResume() {
        super.onResume()
        activity?.let {
            NavigationUtils.setupAdminNavigation(it, NavigationUtils.AdminTab.APPOINTMENT)
        }
    }

    private fun setupRecyclerView() {
        adapter = AdminAppointmentAdapter(
            appointments = appointmentList,
            onAcceptClick = { item ->
                AppointmentRepository.acceptAppointment(requireContext(), item.id)
                Toast.makeText(requireContext(), "Appointment for ${item.patientName} Accepted", Toast.LENGTH_SHORT).show()
            },
            onDeleteClick = { item ->
                AppointmentRepository.deleteByAdminList(requireContext(), item.id)
                Toast.makeText(requireContext(), "Appointment removed from admin view", Toast.LENGTH_SHORT).show()
            }
        )

        rvAppointments.layoutManager = LinearLayoutManager(requireContext())
        rvAppointments.adapter = adapter
    }

    private fun observeLiveAppointments() {
        AppointmentRepository.liveAppointments.observe(viewLifecycleOwner) { updatedList ->
            appointmentList.clear()

            val visibleItems = updatedList.filter { !it.isDeletedByAdmin && !it.isDeletedCompletely }
            appointmentList.addAll(visibleItems)
            adapter.notifyDataSetChanged()

            // Toggle empty state visibility
            if (visibleItems.isEmpty()) {
                layoutEmptyAppointments.visibility = View.VISIBLE
                rvAppointments.visibility = View.GONE
            } else {
                layoutEmptyAppointments.visibility = View.GONE
                rvAppointments.visibility = View.VISIBLE
            }
        }
    }
}