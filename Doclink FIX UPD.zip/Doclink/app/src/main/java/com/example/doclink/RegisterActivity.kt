package com.example.doclink

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Patterns
import android.view.MotionEvent
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        setupBackPressHandler()

        val etUsername = findViewById<EditText?>(R.id.etUsername)
        val etEmail = findViewById<EditText?>(R.id.etEmail)
        val etContact = findViewById<EditText?>(R.id.etContact)
        val etPassword = findViewById<EditText?>(R.id.etPassword)

        val btnRegister = findViewById<Button?>(R.id.btnRegister)
        val tvLogin = findViewById<TextView?>(R.id.tvLogin)

        btnRegister?.setOnClickListener {
            val username = etUsername?.text?.toString()?.trim().orEmpty()
            val email = etEmail?.text?.toString()?.trim().orEmpty()
            val contact = etContact?.text?.toString()?.trim().orEmpty()
            val password = etPassword?.text?.toString()?.trim().orEmpty()

            var isValid = true

            if (username.isEmpty()) {
                etUsername?.error = "Username is required"
                isValid = false
            }

            if (email.isEmpty()) {
                etEmail?.error = "Email address is required"
                isValid = false
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail?.error = "Please enter a valid email address"
                isValid = false
            }

            if (contact.isEmpty()) {
                etContact?.error = "Contact number is required"
                isValid = false
            }

            if (password.isEmpty()) {
                etPassword?.error = "Password is required"
                isValid = false
            } else if (password.length < 6) {
                etPassword?.error = "Password must be at least 6 characters"
                isValid = false
            }

            if (!isValid) return@setOnClickListener

            val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

            val userKey = username.lowercase()
            if (sharedPref.contains("USER_${userKey}_PASS")) {
                etUsername?.error = "Username is already registered"
                return@setOnClickListener
            }

            with(sharedPref.edit()) {
                putString("CURRENT_LOGGED_IN_USER", username)
                putString("REGISTERED_NAME", username)
                putString("USER_NAME", username)
                putString("USER_${userKey}_USERNAME", username)
                putString("USER_${userKey}_EMAIL", email)
                putString("USER_${userKey}_CONTACT", contact)
                putString("USER_${userKey}_PASS", password)

                putString("EMAIL_MAP_${email.lowercase()}", username)
                apply()
            }

            Toast.makeText(this, "Account Registered Successfully!", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, MainPatientActivity::class.java).apply {
                putExtra("USER_NAME", username)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            overridePendingTransition(0, 0)
            finishAffinity()
        }

        tvLogin?.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> (v as TextView).setTextColor(Color.parseColor("#0F2552"))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> (v as TextView).setTextColor(Color.parseColor("#3B82F6"))
            }
            false
        }

        tvLogin?.setOnClickListener {
            finish()
            overridePendingTransition(0, 0)
        }
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
                overridePendingTransition(0, 0)
            }
        })
    }
}