package com.example.doclink

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import org.json.JSONArray
import org.json.JSONObject

object AppointmentRepository {

    private val appointments = mutableListOf<AppointmentItem>()
    private val _liveAppointments = MutableLiveData<List<AppointmentItem>>(emptyList())
    val liveAppointments: LiveData<List<AppointmentItem>> get() = _liveAppointments

    private const val PREF_NAME = "SharedAppointmentsPref"
    private const val KEY_APPOINTMENTS = "ALL_APPOINTMENTS_JSON"

    @Volatile
    private var isInitialized = false

    fun init(context: Context) {
        if (isInitialized) {
            _liveAppointments.value = appointments.toList()
            return
        }

        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_APPOINTMENTS, "[]") ?: "[]"

        appointments.clear()
        try {
            val jsonArray = JSONArray(jsonStr)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                appointments.add(
                    AppointmentItem(
                        id = obj.optString("id", ""),
                        patientName = obj.optString("patientName", ""),
                        doctorName = obj.optString("doctorName", ""),
                        specialty = obj.optString("specialty", ""),
                        dateTime = obj.optString("dateTime", ""),
                        status = obj.optString("status", "Pending"),
                        patientImageRes = R.drawable.user_avatar,
                        isDeletedByPatient = obj.optBoolean("isDeletedByPatient", false),
                        isDeletedByAdmin = obj.optBoolean("isDeletedByAdmin", false),
                        isDeletedCompletely = obj.optBoolean("isDeletedCompletely", false)
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        isInitialized = true
        _liveAppointments.value = appointments.toList()
    }

    /**
     * Adds a new appointment or updates an existing one if the ID exists (Reschedule handling).
     */
    fun addAppointment(context: Context, item: AppointmentItem) {
        if (!isInitialized) {
            init(context)
        }

        val cleanItem = item.copy(
            isDeletedByPatient = false,
            isDeletedByAdmin = false,
            isDeletedCompletely = false
        )

        val existingIndex = appointments.indexOfFirst { it.id == cleanItem.id }
        if (existingIndex != -1) {
            // Overwrite existing appointment (Reschedule)
            appointments[existingIndex] = cleanItem
        } else {
            // Insert new appointment at the beginning
            appointments.add(0, cleanItem)
        }

        _liveAppointments.value = appointments.toList()
        saveToStorage(context)
    }

    fun acceptAppointment(context: Context, id: String) {
        val index = appointments.indexOfFirst { it.id == id }
        if (index != -1) {
            appointments[index] = appointments[index].copy(status = "Accepted")
            _liveAppointments.value = appointments.toList()
            saveToStorage(context)
        }
    }

    /**
     * Cancels an appointment from the patient side and updates status so the Admin panel reflects it immediately.
     */
    fun deleteByPatient(context: Context, id: String) {
        val index = appointments.indexOfFirst { it.id == id }
        if (index != -1) {
            val current = appointments[index]
            appointments[index] = current.copy(
                status = "Cancelled",
                isDeletedByPatient = true,
                isDeletedByAdmin = current.isDeletedByAdmin,
                isDeletedCompletely = true
            )
            _liveAppointments.value = appointments.toList()
            saveToStorage(context)
        }
    }

    fun deleteByAdminList(context: Context, id: String) {
        val index = appointments.indexOfFirst { it.id == id }
        if (index != -1) {
            val current = appointments[index]
            appointments[index] = current.copy(
                isDeletedByAdmin = true,
                isDeletedByPatient = current.isDeletedByPatient,
                isDeletedCompletely = false
            )
            _liveAppointments.value = appointments.toList()
            saveToStorage(context)
        }
    }

    fun deleteCompletely(context: Context, id: String) {
        val index = appointments.indexOfFirst { it.id == id }
        if (index != -1) {
            appointments[index] = appointments[index].copy(isDeletedCompletely = true)
            _liveAppointments.value = appointments.toList()
            saveToStorage(context)
        }
    }

    private fun saveToStorage(context: Context) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val jsonArray = JSONArray()

        for (item in appointments) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("patientName", item.patientName)
                put("doctorName", item.doctorName)
                put("specialty", item.specialty)
                put("dateTime", item.dateTime)
                put("status", item.status)
                put("isDeletedByPatient", item.isDeletedByPatient)
                put("isDeletedByAdmin", item.isDeletedByAdmin)
                put("isDeletedCompletely", item.isDeletedCompletely)
            }
            jsonArray.put(obj)
        }

        prefs.edit().putString(KEY_APPOINTMENTS, jsonArray.toString()).apply()
    }
}