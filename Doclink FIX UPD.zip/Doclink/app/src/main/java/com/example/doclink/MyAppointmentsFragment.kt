package com.example.doclink

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.cardview.widget.CardView
import androidx.fragment.app.Fragment
import com.example.doclink.databinding.FragmentMyAppointmentsBinding

class MyAppointmentsFragment : Fragment() {

    private var _binding: FragmentMyAppointmentsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMyAppointmentsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val context = requireContext()
        AppointmentRepository.init(context)

        observeLiveAppointments()
    }

    override fun onResume() {
        super.onResume()
        context?.let { AppointmentRepository.init(it) }
        displayBookedAppointments()
    }

    private fun observeLiveAppointments() {
        AppointmentRepository.liveAppointments.observe(viewLifecycleOwner) { _ ->
            displayBookedAppointments()
        }
    }

    private fun displayBookedAppointments() {
        val liveList = AppointmentRepository.liveAppointments.value ?: emptyList()

        // Filter out appointments that are deleted or cancelled
        val activeLiveList = liveList.filter {
            !it.isDeletedByPatient &&
                    !it.isDeletedCompletely &&
                    !it.status.equals("Cancelled", ignoreCase = true)
        }

        binding.containerAppointments.removeAllViews()

        if (activeLiveList.isEmpty()) {
            binding.layoutEmptyState.visibility = View.VISIBLE
            return
        }

        binding.layoutEmptyState.visibility = View.GONE

        for (item in activeLiveList) {
            val cardView = createAppointmentCardView(
                appointmentId = item.id,
                doctorId = "doc1", // Default doctor ID
                doctorName = item.doctorName,
                doctorSpecialty = item.specialty,
                dateTime = item.dateTime,
                status = item.status
            )
            binding.containerAppointments.addView(cardView)
        }
    }

    private fun createAppointmentCardView(
        appointmentId: String,
        doctorId: String,
        doctorName: String,
        doctorSpecialty: String,
        dateTime: String,
        status: String
    ): View {
        val context = requireContext()
        val isConfirmed = status.equals("Accepted", ignoreCase = true) || status.equals("Confirmed", ignoreCase = true)

        val card = CardView(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 36)
            }
            radius = 32f
            cardElevation = 6f
            setCardBackgroundColor(Color.WHITE)
        }

        val cardContent = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }

        val headerContainer = RelativeLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val infoRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val imgDoctor = com.google.android.material.imageview.ShapeableImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(140, 140)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setImageResource(R.drawable.ic_doctor_male)
        }

        val textDetailsLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                setMargins(28, 0, 0, 0)
            }
        }

        val tvName = TextView(context).apply {
            text = doctorName
            textSize = 20f
            setTextColor(Color.parseColor("#1E293B"))
            setTypeface(null, Typeface.BOLD)
        }

        val tvSpecialty = TextView(context).apply {
            text = doctorSpecialty
            textSize = 17f
            setTextColor(Color.parseColor("#94A3B8"))
        }

        val tvAddress = TextView(context).apply {
            text = "Address: Guiwan Clinic"
            textSize = 15f
            setTextColor(Color.parseColor("#94A3B8"))
        }

        textDetailsLayout.addView(tvName)
        textDetailsLayout.addView(tvSpecialty)
        textDetailsLayout.addView(tvAddress)

        val tvStatus = TextView(context).apply {
            text = if (isConfirmed) "Confirmed" else "Pending"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(
                if (isConfirmed)
                    Color.parseColor("#22C55E")
                else
                    Color.parseColor("#EF4444")
            )
        }

        infoRow.addView(imgDoctor)
        infoRow.addView(textDetailsLayout)
        infoRow.addView(tvStatus)
        headerContainer.addView(infoRow)

        if (isConfirmed) {
            val btnDeleteCard = ImageView(context).apply {
                id = View.generateViewId()
                layoutParams = RelativeLayout.LayoutParams(64, 64).apply {
                    addRule(RelativeLayout.ALIGN_PARENT_END)
                    addRule(RelativeLayout.ALIGN_PARENT_TOP)
                }
                setImageResource(R.drawable.ic_close)
                setColorFilter(Color.parseColor("#94A3B8"))
                setPadding(8, 8, 8, 8)

                setOnClickListener {
                    setColorFilter(Color.parseColor("#EF4444"))
                    postDelayed({
                        showDeleteConfirmationDialog(appointmentId)
                    }, 150)
                }
            }

            (infoRow.layoutParams as RelativeLayout.LayoutParams).apply {
                addRule(RelativeLayout.LEFT_OF, btnDeleteCard.id)
                marginEnd = 16
            }
            headerContainer.addView(btnDeleteCard)
        }

        val tvDateTime = TextView(context).apply {
            text = "Date & Time: $dateTime"
            textSize = 15f
            setTextColor(Color.parseColor("#334155"))
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 24, 0, 0)
        }

        cardContent.addView(headerContainer)
        cardContent.addView(tvDateTime)

        if (!isConfirmed) {
            val buttonRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 24, 0, 0)
            }

            val btnReschedule = AppCompatButton(context).apply {
                layoutParams = LinearLayout.LayoutParams(0, 100, 1f).apply {
                    marginEnd = 12
                }
                setBackgroundResource(R.drawable.bg_primary_button)
                text = "Reschedule"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTypeface(null, Typeface.BOLD)
                setOnClickListener {
                    val intent = Intent(requireContext(), BookAppointmentActivity::class.java).apply {
                        putExtra("APPOINTMENT_ID", appointmentId)
                        putExtra("DOCTOR_ID", doctorId)
                        putExtra("DOCTOR_NAME", doctorName)
                        putExtra("DOCTOR_SPECIALTY", doctorSpecialty)
                        putExtra("IS_RESCHEDULE", true)
                        flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    startActivity(intent)
                    requireActivity().overridePendingTransition(0, 0)
                }
            }

            val btnCancel = AppCompatButton(context).apply {
                layoutParams = LinearLayout.LayoutParams(0, 100, 1f).apply {
                    marginStart = 12
                }
                setBackgroundResource(R.drawable.bg_danger_button)
                text = "Cancel"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTypeface(null, Typeface.BOLD)
                setOnClickListener {
                    showCancelDialog(appointmentId)
                }
            }

            apply3DPushEffect(btnReschedule)
            apply3DPushEffect(btnCancel)

            buttonRow.addView(btnReschedule)
            buttonRow.addView(btnCancel)
            cardContent.addView(buttonRow)
        }

        card.addView(cardContent)
        return card
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun apply3DPushEffect(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate()
                        .scaleX(0.93f)
                        .scaleY(0.93f)
                        .translationZ(-4f)
                        .setDuration(80)
                        .start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate()
                        .scaleX(1.0f)
                        .scaleY(1.0f)
                        .translationZ(0f)
                        .setDuration(100)
                        .start()
                }
            }
            false
        }
    }

    private fun showDeleteConfirmationDialog(targetAppointmentId: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Appointment")
            .setMessage("Are you sure you want to remove this confirmed appointment?")
            .setPositiveButton("Yes") { dialog, _ ->
                removeAppointmentById(targetAppointmentId)
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showCancelDialog(targetAppointmentId: String) {
        AlertDialog.Builder(requireContext())
            .setTitle("Cancel Appointment")
            .setMessage("Are you sure you want to cancel this pending appointment?")
            .setPositiveButton("Yes") { dialog, _ ->
                removeAppointmentById(targetAppointmentId)
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun removeAppointmentById(targetId: String) {
        if (targetId.isEmpty()) return
        val context = requireContext()

        // Calls deleteByPatient which marks status as Cancelled and flags it complete across patient & admin
        AppointmentRepository.deleteByPatient(context, targetId)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}