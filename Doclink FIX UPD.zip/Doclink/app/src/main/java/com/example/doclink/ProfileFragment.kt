package com.example.doclink

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class ProfileFragment : Fragment() {

    private lateinit var tvProfileUsername: TextView
    private lateinit var tvProfileEmail: TextView
    private lateinit var tvProfileContact: TextView
    private lateinit var tvLogout: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        tvProfileUsername = view.findViewById(R.id.tvProfileUsername)
        tvProfileEmail = view.findViewById(R.id.tvProfileEmail)
        tvProfileContact = view.findViewById(R.id.tvProfileContact)
        tvLogout = view.findViewById(R.id.tvLogout)

        loadUserData()

        tvLogout.setOnClickListener {
            showLogoutDialog()
        }

        return view
    }

    private fun loadUserData() {
        val ctx = context ?: return
        val sharedPref = ctx.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)

        val activeUser = sharedPref.getString("CURRENT_LOGGED_IN_USER", "Patient") ?: "Patient"
        val userKey = activeUser.lowercase()

        val username = sharedPref.getString("USER_${userKey}_USERNAME", activeUser) ?: activeUser
        val email = sharedPref.getString("USER_${userKey}_EMAIL", "patient@doclink.com") ?: "patient@doclink.com"
        val rawContact = sharedPref.getString("USER_${userKey}_CONTACT", "09522389389") ?: "09522389389"

        tvProfileUsername.text = username
        tvProfileEmail.text = email
        tvProfileContact.text = formatPhoneNumber(rawContact)
    }

    private fun formatPhoneNumber(rawContact: String): String {
        val digitsOnly = rawContact.replace(Regex("[^0-9]"), "")

        return when {
            digitsOnly.startsWith("09") && digitsOnly.length == 11 -> {
                val subscriber = digitsOnly.substring(1)
                "+63 ${subscriber.substring(0, 3)} ${subscriber.substring(3, 7)} ${subscriber.substring(7)}"
            }
            digitsOnly.startsWith("9") && digitsOnly.length == 10 -> {
                "+63 ${digitsOnly.substring(0, 3)} ${digitsOnly.substring(3, 7)} ${digitsOnly.substring(7)}"
            }
            digitsOnly.startsWith("63") && digitsOnly.length == 12 -> {
                val subscriber = digitsOnly.substring(2)
                "+63 ${subscriber.substring(0, 3)} ${subscriber.substring(3, 7)} ${subscriber.substring(7)}"
            }
            else -> rawContact
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showLogoutDialog() {
        val act = activity ?: return

        val dialog = AlertDialog.Builder(act)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("OK", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()

        val btnPositive = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        val btnNegative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

        val defaultBlue = Color.parseColor("#0284C7")
        val defaultGray = Color.parseColor("#64748B")
        val navyBlue = Color.parseColor("#000080")

        listOfNotNull(btnPositive, btnNegative).forEach { button ->
            button.background = ColorDrawable(Color.TRANSPARENT)
            button.stateListAnimator = null
            button.elevation = 0f
        }

        btnPositive?.setTextColor(defaultBlue)
        btnNegative?.setTextColor(defaultGray)

        btnPositive?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> btnPositive.setTextColor(navyBlue)
                MotionEvent.ACTION_UP -> {
                    btnPositive.setTextColor(defaultBlue)
                    dialog.dismiss()
                    performLogout()
                }
                MotionEvent.ACTION_CANCEL -> btnPositive.setTextColor(defaultBlue)
            }
            true
        }

        btnNegative?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> btnNegative.setTextColor(navyBlue)
                MotionEvent.ACTION_UP -> {
                    btnNegative.setTextColor(defaultGray)
                    dialog.dismiss()
                }
                MotionEvent.ACTION_CANCEL -> btnNegative.setTextColor(defaultGray)
            }
            true
        }
    }

    private fun performLogout() {
        val act = activity ?: return
        val sharedPref = act.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        sharedPref.edit().remove("CURRENT_LOGGED_IN_USER").apply()

        val intent = Intent(act, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        act.finish()
    }
}