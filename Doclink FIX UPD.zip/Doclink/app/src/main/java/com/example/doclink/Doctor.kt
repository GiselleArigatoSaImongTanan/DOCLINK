package com.example.doclink

import java.io.Serializable

data class Doctor(
    val id: String,
    val name: String,
    val specialty: String,
    val address: String,
    val isAvailable: Boolean = true,
    val isActive: Boolean = true,
    val nextAvailableTime: String = "",
    val imageRes: Int = R.drawable.ic_doctor_male,
    val description1: String = "",
    val description2: String = ""
) : Serializable