package com.example.doclink

import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.SwitchCompat

class AdminEditDoctorTimeActivity : AppCompatActivity() {

    private var doctorId: String? = null
    private var selectedTimeSlot: String = "10:00 AM"

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_edit_doctor_time)

        doctorId = intent.getStringExtra("EXTRA_DOCTOR_ID")
        val doctor = DoctorRepository.getDoctorById(this, doctorId ?: "")

        val btnBack = findViewById<ImageView>(R.id.btnAdminEditBack)
        val btnMenu = findViewById<ImageView>(R.id.btnAdminMenu)
        val switchAvailable = findViewById<SwitchCompat>(R.id.switchAdminAvailable)
        val tvStatusLabel = findViewById<TextView>(R.id.tvAdminStatusLabel)
        val btnSave = findViewById<AppCompatButton>(R.id.btnAdminSave)

        val timeSlots = listOf(
            findViewById<TextView>(R.id.adminTimeSlot1),
            findViewById<TextView>(R.id.adminTimeSlot2),
            findViewById<TextView>(R.id.adminTimeSlot3),
            findViewById<TextView>(R.id.adminTimeSlot4),
            findViewById<TextView>(R.id.adminTimeSlot5)
        )

        btnBack.setOnClickListener {
            finish()
        }

        // Handle 3-Dot Menu Click (Remove / Restore Doctor)
        btnMenu?.setOnClickListener { view ->
            val currentDoctor = DoctorRepository.getDoctorById(this, doctorId ?: "") ?: return@setOnClickListener
            val popup = PopupMenu(this, view)

            if (currentDoctor.isActive) {
                popup.menu.add("Remove Doctor")
            } else {
                popup.menu.add("Restore Doctor")
            }

            popup.setOnMenuItemClickListener { menuItem ->
                when (menuItem.title) {
                    "Remove Doctor" -> {
                        showRemoveConfirmationDialog(currentDoctor)
                        true
                    }
                    "Restore Doctor" -> {
                        showRestoreConfirmationDialog(currentDoctor)
                        true
                    }
                    else -> false
                }
            }
            popup.show()
        }

        // Load initial state cleanly
        if (doctor != null) {
            switchAvailable.isChecked = doctor.isAvailable
            updateSwitchState(switchAvailable.isChecked, tvStatusLabel, timeSlots)

            // Select active time slot if previously set
            if (doctor.isAvailable && doctor.nextAvailableTime.isNotEmpty()) {
                val cleanTime = doctor.nextAvailableTime.replace(" tomorrow", "").trim()
                timeSlots.find { it.text.toString().replace("\n", " ").equals(cleanTime, ignoreCase = true) }?.let { slot ->
                    selectedTimeSlot = cleanTime
                    highlightTimeSlot(timeSlots, slot)
                }
            }
        }

        // Toggle Switch handler
        switchAvailable.setOnCheckedChangeListener { _, isChecked ->
            updateSwitchState(isChecked, tvStatusLabel, timeSlots)
        }

        // Time Slots selection
        timeSlots.forEach { slot ->
            slot.setOnClickListener {
                if (switchAvailable.isChecked) {
                    selectedTimeSlot = slot.text.toString().replace("\n", " ")
                    highlightTimeSlot(timeSlots, slot)
                }
            }
        }

        // Save & Sync State
        btnSave.setOnClickListener {
            if (doctorId != null) {
                val isAvailable = switchAvailable.isChecked
                val updatedTime = if (isAvailable) "$selectedTimeSlot tomorrow" else "Not Available"

                DoctorRepository.updateDoctorAvailability(
                    context = this,
                    doctorId = doctorId!!,
                    isAvailable = isAvailable,
                    newTime = updatedTime
                )

                Toast.makeText(this, "Doctor schedule updated!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun showRemoveConfirmationDialog(doctor: Doctor) {
        AlertDialog.Builder(this)
            .setTitle("Remove Doctor")
            .setMessage("Are you sure you want to remove ${doctor.name} from the patient view?")
            .setPositiveButton("Remove") { dialog, _ ->
                DoctorRepository.removeDoctor(this, doctor.id)
                Toast.makeText(this, "${doctor.name} removed from patient view.", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun showRestoreConfirmationDialog(doctor: Doctor) {
        AlertDialog.Builder(this)
            .setTitle("Restore Doctor")
            .setMessage("Do you want to restore ${doctor.name} so patients can see and book them again?")
            .setPositiveButton("Restore") { dialog, _ ->
                DoctorRepository.restoreDoctor(this, doctor.id)
                Toast.makeText(this, "${doctor.name} restored successfully.", Toast.LENGTH_SHORT).show()
                finish()
            }
            .setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
            .show()
    }

    private fun updateSwitchState(isChecked: Boolean, label: TextView, slots: List<TextView>) {
        if (isChecked) {
            label.text = "Available"
            label.setTextColor(Color.parseColor("#22C55E"))
            slots.forEach {
                it.isEnabled = true
                it.alpha = 1.0f
            }
        } else {
            label.text = "Not Available"
            label.setTextColor(Color.parseColor("#EF4444"))
            slots.forEach {
                it.isEnabled = false
                it.alpha = 0.4f
                it.isSelected = false
            }
        }
    }

    private fun highlightTimeSlot(slots: List<TextView>, selected: TextView) {
        slots.forEach { slot ->
            slot.isSelected = (slot == selected)
        }
    }
}