package com.example.doclink

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.InputMethodManager
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.doclink.databinding.ActivityDoctorsBinding

class DoctorsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDoctorsBinding
    private lateinit var doctorAdapter: DoctorAdapter
    private var fullDoctorsList = listOf<Doctor>()

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        binding = ActivityDoctorsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AppointmentRepository.init(this)
        setupBackHandling()

        binding.btnBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        binding.btnClearDoctorsSearch.setOnClickListener {
            binding.etSearchDoctors.setText("")
            filterDoctors("")
        }

        binding.rvDoctorsList.layoutManager = LinearLayoutManager(this)
        doctorAdapter = DoctorAdapter(emptyList()) { selectedDoctor ->
            val intent = Intent(this, DoctorDetailsActivity::class.java).apply {
                putExtra("DOCTOR_ID", selectedDoctor.id)
                putExtra("EXTRA_DOCTOR", selectedDoctor)
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            }
            startActivity(intent)
            overridePendingTransition(0, 0)
        }
        binding.rvDoctorsList.adapter = doctorAdapter

        binding.etSearchDoctors.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                filterDoctors(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        val initialQuery = intent.getStringExtra("EXTRA_SEARCH_QUERY") ?: ""
        if (initialQuery.isNotEmpty()) {
            binding.etSearchDoctors.setText(initialQuery)
            binding.etSearchDoctors.setSelection(initialQuery.length)
        }

        // Observe live appointments to dynamically compute the next available open slot
        observeAppointmentsAndDoctors()

        if (savedInstanceState == null && initialQuery.isNotEmpty()) {
            binding.etSearchDoctors.requestFocus()
            binding.etSearchDoctors.post {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.showSoftInput(binding.etSearchDoctors, InputMethodManager.SHOW_IMPLICIT)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshDoctorsList()
    }

    private fun observeAppointmentsAndDoctors() {
        AppointmentRepository.liveAppointments.observe(this) { _ ->
            refreshDoctorsList()
        }
    }

    private fun refreshDoctorsList() {
        // Fetch ONLY active (non-removed) doctors for patient search screen
        val baseDoctors = DoctorRepository.getActiveDoctors(this)
        // Access active appointments directly from LiveData
        val activeAppointments = AppointmentRepository.liveAppointments.value ?: emptyList()

        fullDoctorsList = baseDoctors.map { doctor ->
            if (doctor.isAvailable) {
                val dynamicTime = calculateNextAvailableTime(doctor.name, activeAppointments)
                doctor.copy(nextAvailableTime = dynamicTime)
            } else {
                doctor
            }
        }

        filterDoctors(binding.etSearchDoctors.text.toString())
    }

    private fun calculateNextAvailableTime(doctorName: String, appointments: List<AppointmentItem>): String {
        val defaultSlots = listOf(
            "10:00 AM tomorrow",
            "11:00 AM tomorrow",
            "01:00 PM tomorrow",
            "02:00 PM tomorrow",
            "03:00 PM tomorrow",
            "04:00 PM tomorrow"
        )

        val bookedTimes = appointments
            .filter { it.doctorName.equals(doctorName, ignoreCase = true) && !it.isDeletedCompletely }
            .map { it.dateTime }

        val firstFreeSlot = defaultSlots.firstOrNull { slot ->
            bookedTimes.none { booked -> booked.contains(slot, ignoreCase = true) }
        }

        return firstFreeSlot ?: "Fully Booked tomorrow"
    }

    private fun filterDoctors(query: String) {
        val trimmedQuery = query.trim()

        if (trimmedQuery.isEmpty()) {
            doctorAdapter.updateList(fullDoctorsList)
            return
        }

        val tokens = extractSearchTokens(trimmedQuery)

        val filtered = fullDoctorsList.filter { doctor ->
            val targetText = sanitizeText("${doctor.name} ${doctor.specialty} ${doctor.address}")
            tokens.all { token -> targetText.contains(token) }
        }

        doctorAdapter.updateList(filtered)
    }

    private fun extractSearchTokens(text: String): List<String> {
        val cleanText = sanitizeText(text)
        if (cleanText.isEmpty()) return emptyList()

        return cleanText.split("\\s+".toRegex()).filter { it.isNotEmpty() }
    }

    private fun sanitizeText(text: String): String {
        return text.lowercase()
            .replace(".", "")
            .replace(",", "")
            .trim()
    }

    private fun setupBackHandling() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
                overridePendingTransition(0, 0)
            }
        })
    }

    override fun finish() {
        super.finish()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }
}