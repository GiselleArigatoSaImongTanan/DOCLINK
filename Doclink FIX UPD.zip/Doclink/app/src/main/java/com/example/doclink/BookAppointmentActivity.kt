package com.example.doclink

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.doclink.databinding.ActivityBookAppointmentBinding
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class BookAppointmentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookAppointmentBinding
    private var selectedCalendar: Calendar = Calendar.getInstance()
    private var selectedTime: String = ""
    private var doctorId: String = ""
    private var doctorName: String = ""
    private var doctorSpecialty: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)

        binding = ActivityBookAppointmentBinding.inflate(layoutInflater)
        setContentView(binding.root)

        AppointmentRepository.init(this)

        // Read intent inputs or lookup from central repository
        doctorId = intent.getStringExtra("DOCTOR_ID") ?: "doc1"

        val repoDoctor = DoctorRepository.getDoctorById(this, doctorId)

        doctorName = intent.getStringExtra("DOCTOR_NAME")
            ?: repoDoctor?.name
                    ?: "Dr. Jeo Dina Kya"

        doctorSpecialty = intent.getStringExtra("DOCTOR_SPECIALTY")
            ?: repoDoctor?.specialty
                    ?: "OB-GYN"

        binding.btnBack.setOnClickListener {
            finish()
            overridePendingTransition(0, 0)
        }

        Looper.myLooper()?.let { looper ->
            Handler(looper).post {
                setupInitialDate()
                setupCalendar()
                setupTimeSlots()
                setupConfirmButton()
            }
        }
    }

    private fun setupInitialDate() {
        val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        binding.tvMonthYear.text = monthFormat.format(selectedCalendar.time)
    }

    private fun setupCalendar() {
        binding.calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedCalendar.set(Calendar.YEAR, year)
            selectedCalendar.set(Calendar.MONTH, month)
            selectedCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val monthFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
            binding.tvMonthYear.text = monthFormat.format(selectedCalendar.time)
        }
    }

    private fun setupTimeSlots() {
        val slots = listOf(
            binding.timeSlot1,
            binding.timeSlot2,
            binding.timeSlot3,
            binding.timeSlot4,
            binding.timeSlot5
        )

        slots.forEach { slot ->
            slot.setOnClickListener {
                selectTimeSlot(slot, slots)
            }
        }
    }

    private fun selectTimeSlot(selectedSlot: TextView, allSlots: List<TextView>) {
        allSlots.forEach { it.isSelected = false }
        selectedSlot.isSelected = true
        selectedTime = selectedSlot.text.toString().replace("\n", " ")
    }

    private fun setupConfirmButton() {
        binding.btnConfirm.setOnClickListener {
            if (selectedTime.isEmpty()) {
                Toast.makeText(this, "Please select a time slot", Toast.LENGTH_SHORT).show()
            } else {
                showSuccessDialog()
            }
        }
    }

    private fun showSuccessDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_appointment_success, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val imgThumbUp = dialogView.findViewById<ImageView>(R.id.imgThumbUp)
        val tvSuccessDetails = dialogView.findViewById<TextView>(R.id.tvSuccessDetails)
        val btnDone = dialogView.findViewById<View>(R.id.btnDone)

        imgThumbUp?.setImageResource(R.drawable.ic_thumb_up)
        imgThumbUp?.imageTintList = null

        val dialogDateFormat = SimpleDateFormat("MMMM d", Locale.getDefault())
        val formattedDialogDate = dialogDateFormat.format(selectedCalendar.time)

        tvSuccessDetails.text = "You booked an appointment with $doctorName on $formattedDialogDate,\n at $selectedTime"

        btnDone?.setOnClickListener {
            btnDone.isEnabled = false
            dialog.dismiss()

            val fullDateFormat = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
            val formattedFullDate = fullDateFormat.format(selectedCalendar.time)

            // Resolve patient name robustly across common preference keys
            val userPrefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            val savedName = userPrefs.getString("REGISTERED_NAME", null)
                ?: userPrefs.getString("USER_NAME", null)
                ?: userPrefs.getString("PATIENT_NAME", null)
                ?: userPrefs.getString("KEY_USER_NAME", null)

            val patientName = intent.getStringExtra("LOGGED_IN_PATIENT_NAME")
                ?: intent.getStringExtra("USER_NAME")
                ?: savedName
                ?: "Registered Patient"

            val fullDateTimeString = "$formattedFullDate  |  $selectedTime"
            val isReschedule = intent.getBooleanExtra("IS_RESCHEDULE", false)
            val existingApptId = intent.getStringExtra("APPOINTMENT_ID")

            val appointmentId = if (isReschedule && !existingApptId.isNullOrEmpty()) {
                existingApptId
            } else {
                System.currentTimeMillis().toString()
            }

            val newAppointment = AppointmentItem(
                id = appointmentId,
                patientName = patientName,
                doctorName = doctorName,
                specialty = doctorSpecialty,
                dateTime = fullDateTimeString,
                status = "Pending",
                patientImageRes = R.drawable.user_avatar
            )

            // Add to centralized repository
            AppointmentRepository.addAppointment(this, newAppointment)

            // Save strictly by appointmentId to local shared preferences
            saveAppointmentToPreferences(appointmentId, doctorId, doctorName, doctorSpecialty, formattedFullDate, selectedTime)

            // Target MainPatientActivity and request the APPOINTMENT tab
            val intent = Intent(this, MainPatientActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("OPEN_TAB", "APPOINTMENT")
            }
            startActivity(intent)
            finish()
            overridePendingTransition(0, 0)
        }

        dialog.show()
    }

    private fun saveAppointmentToPreferences(
        apptId: String,
        id: String,
        name: String,
        specialty: String,
        date: String,
        time: String
    ) {
        val sharedPref = getSharedPreferences("UserAppointments", Context.MODE_PRIVATE)
        val existingJsonStr = sharedPref.getString("APPOINTMENTS_LIST", "[]") ?: "[]"

        try {
            val jsonArray = JSONArray(existingJsonStr)
            var isUpdated = false

            for (i in 0 until jsonArray.length()) {
                val item = jsonArray.getJSONObject(i)
                if (item.optString("id") == apptId) {
                    item.put("appointmentDate", date)
                    item.put("appointmentTime", time)
                    item.put("status", "Pending")
                    item.put("timestamp", System.currentTimeMillis())
                    isUpdated = true
                    break
                }
            }

            if (!isUpdated) {
                val newAppointment = JSONObject().apply {
                    put("id", apptId)
                    put("doctorId", id)
                    put("doctorName", name)
                    put("doctorSpecialty", specialty)
                    put("appointmentDate", date)
                    put("appointmentTime", time)
                    put("status", "Pending")
                    put("timestamp", System.currentTimeMillis())
                }
                jsonArray.put(newAppointment)
            }

            sharedPref.edit().putString("APPOINTMENTS_LIST", jsonArray.toString()).apply()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(0, 0)
    }
}