package com.example.doclink

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

object NavigationUtils {

    enum class NavTab {
        HOME, APPOINTMENT, NOTIFICATION, PROFILE
    }

    enum class AdminTab {
        HOME, APPOINTMENT, ADD_DOCTOR, DOCTOR_LIST
    }

    fun setupBottomNavigation(activity: Activity, currentTab: NavTab) {
        val mainActivity = activity as? MainPatientActivity ?: return

        val navHome = activity.findViewById<View>(R.id.navHome)
        val navAppointment = activity.findViewById<View>(R.id.navAppointment)
        val navNotification = activity.findViewById<View>(R.id.navNotification)
        val navProfile = activity.findViewById<View>(R.id.navProfile)

        updateTabStyle(navHome, currentTab == NavTab.HOME)
        updateTabStyle(navAppointment, currentTab == NavTab.APPOINTMENT)
        updateTabStyle(navNotification, currentTab == NavTab.NOTIFICATION)
        updateTabStyle(navProfile, currentTab == NavTab.PROFILE)

        navHome?.setOnClickListener {
            if (currentTab != NavTab.HOME) {
                mainActivity.switchFragment(PatientHomeFragment(), NavTab.HOME)
            }
        }

        navAppointment?.setOnClickListener {
            if (currentTab != NavTab.APPOINTMENT) {
                mainActivity.switchFragment(MyAppointmentsFragment(), NavTab.APPOINTMENT)
            }
        }

        navNotification?.setOnClickListener {
            if (currentTab != NavTab.NOTIFICATION) {
                mainActivity.switchFragment(NotificationsFragment(), NavTab.NOTIFICATION)
            }
        }

        navProfile?.setOnClickListener {
            if (currentTab != NavTab.PROFILE) {
                mainActivity.switchFragment(ProfileFragment(), NavTab.PROFILE)
            }
        }
    }

    fun setupAdminNavigation(activity: Activity, currentTab: AdminTab) {
        val mainAdminActivity = activity as? MainAdminActivity ?: return

        val adminNavHome = activity.findViewById<View>(R.id.adminNavHome)
        val adminNavAppointment = activity.findViewById<View>(R.id.adminNavAppointment)
        val adminNavAddDoctor = activity.findViewById<View>(R.id.adminNavAddDoctor)
        val adminNavDoctorList = activity.findViewById<View>(R.id.adminNavDoctorList)

        updateTabStyle(adminNavHome, currentTab == AdminTab.HOME)
        updateTabStyle(adminNavAppointment, currentTab == AdminTab.APPOINTMENT)
        updateTabStyle(adminNavAddDoctor, currentTab == AdminTab.ADD_DOCTOR)
        updateTabStyle(adminNavDoctorList, currentTab == AdminTab.DOCTOR_LIST)

        adminNavHome?.setOnClickListener {
            if (currentTab != AdminTab.HOME) {
                mainAdminActivity.loadFragment(AdminDashboardFragment())
                mainAdminActivity.updateActiveTab(AdminTab.HOME)
            }
        }

        adminNavAppointment?.setOnClickListener {
            if (currentTab != AdminTab.APPOINTMENT) {
                mainAdminActivity.loadFragment(AdminAppointmentsFragment())
                mainAdminActivity.updateActiveTab(AdminTab.APPOINTMENT)
            }
        }

        adminNavAddDoctor?.setOnClickListener {
            if (currentTab != AdminTab.ADD_DOCTOR) {
                mainAdminActivity.loadFragment(AdminAddDoctorFragment())
                mainAdminActivity.updateActiveTab(AdminTab.ADD_DOCTOR)
            }
        }

        adminNavDoctorList?.setOnClickListener {
            if (currentTab != AdminTab.DOCTOR_LIST) {
                mainAdminActivity.loadFragment(AdminDoctorListFragment())
                mainAdminActivity.updateActiveTab(AdminTab.DOCTOR_LIST)
            }
        }

        setupAdminHeader(activity)
    }

    @SuppressLint("ClickableViewAccessibility")
    fun setupAdminHeader(activity: Activity) {
        val targetView = findViewByName(activity, "layoutAdminHeader")
            ?: (activity.findViewById<View>(R.id.imgAdminAvatar)?.parent as? View)
            ?: findViewByName(activity, "headerContainer")

        targetView?.apply {
            isClickable = true
            isFocusable = true

            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> v.alpha = 0.6f
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1.0f
                }
                false
            }

            setOnClickListener {
                showLogoutDialog(activity)
            }
        }
    }

    private fun showLogoutDialog(activity: Activity) {
        val dialog = AlertDialog.Builder(activity)
            .setTitle("Log Out")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Ok") { d, _ ->
                d.dismiss()

                val intent = Intent(activity, LoginActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }

                activity.startActivity(intent)
                activity.finishAffinity()
                activity.overridePendingTransition(0, 0)
            }
            .setNegativeButton("Cancel") { d, _ -> d.dismiss() }
            .create()

        dialog.show()

        val textDarkColor = Color.parseColor("#1E293B")
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.apply {
            setTextColor(textDarkColor)
            setTypeface(null, Typeface.BOLD)
        }
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.apply {
            setTextColor(textDarkColor)
            setTypeface(null, Typeface.BOLD)
        }

        val dialogBackground = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = 32f
        }
        dialog.window?.setBackgroundDrawable(dialogBackground)
    }

    private fun findViewByName(activity: Activity, viewIdName: String): View? {
        val id = activity.resources.getIdentifier(viewIdName, "id", activity.packageName)
        return if (id != 0) activity.findViewById(id) else null
    }

    private fun updateTabStyle(tabView: View?, isActive: Boolean) {
        if (tabView !is ViewGroup) return

        val activeColor = Color.parseColor("#3B82F6")
        val inactiveColor = Color.parseColor("#94A3B8")

        for (i in 0 until tabView.childCount) {
            when (val child = tabView.getChildAt(i)) {
                is ImageView -> {
                    child.imageTintList = ColorStateList.valueOf(if (isActive) activeColor else inactiveColor)
                }
                is TextView -> {
                    child.setTextColor(if (isActive) activeColor else inactiveColor)
                    child.setTypeface(null, if (isActive) Typeface.BOLD else Typeface.NORMAL)
                }
            }
        }
    }
}