package com.example.doclink

data class AppointmentItem(
    val id: String = "",
    val patientName: String = "",
    val doctorName: String = "",
    val specialty: String = "",
    val dateTime: String = "",
    val status: String = "Pending",
    val patientImageRes: Int = R.drawable.user_avatar,
    val isDeletedByPatient: Boolean = false,
    val isDeletedByAdmin: Boolean = false,
    val isDeletedCompletely: Boolean = false
)