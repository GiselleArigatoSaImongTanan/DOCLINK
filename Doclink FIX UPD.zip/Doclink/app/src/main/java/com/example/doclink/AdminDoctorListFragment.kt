package com.example.doclink

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AdminDoctorListFragment : Fragment() {

    private lateinit var rvAdminDoctorList: RecyclerView
    private lateinit var adapter: AdminDoctorAdapter
    private lateinit var etSearch: EditText
    private lateinit var btnClearSearch: ImageView

    private var fullList = listOf<Doctor>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_doctor_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvAdminDoctorList = view.findViewById(R.id.rvAdminDoctorList)
        etSearch = view.findViewById(R.id.etSearch)
        btnClearSearch = view.findViewById(R.id.btnClearSearch)

        rvAdminDoctorList.layoutManager = LinearLayoutManager(requireContext())

        adapter = AdminDoctorAdapter(
            doctors = emptyList(),
            onEditClick = { doctor ->
                val intent = Intent(requireContext(), AdminEditDoctorTimeActivity::class.java).apply {
                    putExtra("EXTRA_DOCTOR_ID", doctor.id)
                    addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                }
                startActivity(intent)
            },
            onRestoreClick = { doctor ->
                showRestoreConfirmationDialog(doctor)
            }
        )
        rvAdminDoctorList.adapter = adapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                filterList(query)

                btnClearSearch.visibility = if (query.trim().isNotEmpty()) View.VISIBLE else View.GONE
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        btnClearSearch.setOnClickListener {
            etSearch.text.clear()
        }
    }

    override fun onResume() {
        super.onResume()

        activity?.let {
            NavigationUtils.setupAdminNavigation(it, NavigationUtils.AdminTab.DOCTOR_LIST)
        }

        refreshDoctorList()
    }

    private fun refreshDoctorList() {
        // Fetch ALL doctors (Active + Hidden) for Admin
        fullList = DoctorRepository.getAllDoctors(requireContext())
        filterList(etSearch.text.toString())
    }

    private fun showRestoreConfirmationDialog(doctor: Doctor) {
        AlertDialog.Builder(requireContext())
            .setTitle("Restore Doctor")
            .setMessage("Do you want to restore ${doctor.name}? They will become visible to patients again.")
            .setPositiveButton("Restore") { dialog, _ ->
                DoctorRepository.restoreDoctor(requireContext(), doctor.id)
                Toast.makeText(requireContext(), "${doctor.name} restored successfully.", Toast.LENGTH_SHORT).show()
                refreshDoctorList()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun filterList(query: String) {
        val cleanQuery = sanitizeQuery(query)

        if (cleanQuery.isEmpty()) {
            adapter.updateData(fullList)
            return
        }

        val filtered = fullList.filter { doctor ->
            val doctorId = doctor.id.lowercase()
            val rawName = doctor.name.lowercase()
            val sanitizedDoctorName = sanitizeQuery(doctor.name)
            val specialty = doctor.specialty.lowercase()
            val address = doctor.address.lowercase()

            val matchesId = doctorId.contains(cleanQuery)
            val matchesRawName = rawName.contains(cleanQuery)
            val matchesSanitizedName = sanitizedDoctorName.contains(cleanQuery)

            val nameTokens = sanitizedDoctorName.split(" ").filter { it.isNotBlank() }
            val queryTokens = cleanQuery.split(" ").filter { it.isNotBlank() }
            val matchesTokens = queryTokens.all { qToken ->
                nameTokens.any { nToken -> nToken.contains(qToken) }
            }

            val matchesSpecialty = specialty.contains(cleanQuery)
            val matchesAddress = address.contains(cleanQuery)

            matchesId || matchesRawName || matchesSanitizedName || matchesTokens || matchesSpecialty || matchesAddress
        }

        adapter.updateData(filtered)
    }

    private fun sanitizeQuery(input: String): String {
        return input.trim().lowercase()
            .replace(Regex("^dr\\.\\s*|^dr\\s+|^doctor\\s+"), "")
            .trim()
    }
}