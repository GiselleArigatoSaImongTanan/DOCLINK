package com.example.doclink

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationsFragment : Fragment() {

    companion object {
        private const val PREF_NOTIFS = "NotificationsDismissState"
        private const val KEY_DISMISSED_REMINDER = "dismissed_reminder_id"
        private const val KEY_DISMISSED_UPDATES = "dismissed_updates_flag"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_notifications, container, false)
        val context = requireContext()

        val tvReminderHeader = view.findViewById<TextView>(R.id.tvReminderHeader)
        val cardReminder = view.findViewById<ConstraintLayout>(R.id.cardReminder)

        val tvUpdatesHeader = view.findViewById<TextView>(R.id.tvUpdatesHeader)
        val cardUpdates = view.findViewById<ConstraintLayout>(R.id.cardUpdates)

        val layoutNoNotifications = view.findViewById<LinearLayout>(R.id.layoutNoNotifications)

        val tvReminderDate = view.findViewById<TextView>(R.id.tvReminderDate)
        val tvReminderText = view.findViewById<TextView>(R.id.tvReminderText)

        val tvUpdateDate = view.findViewById<TextView>(R.id.tvUpdateDate)
        val tvUpdateText = view.findViewById<TextView>(R.id.tvUpdateText)

        val btnCloseReminder = view.findViewById<ImageView>(R.id.btnCloseReminder)
        val btnCloseUpdates = view.findViewById<ImageView>(R.id.btnCloseUpdates)

        val prefs = context.getSharedPreferences(PREF_NOTIFS, Context.MODE_PRIVATE)

        fun checkEmptyState() {
            val isReminderVisible = cardReminder?.visibility == View.VISIBLE
            val isUpdatesVisible = cardUpdates?.visibility == View.VISIBLE

            if (!isReminderVisible && !isUpdatesVisible) {
                layoutNoNotifications?.visibility = View.VISIBLE
            } else {
                layoutNoNotifications?.visibility = View.GONE
            }
        }

        // --- 1. REAL-TIME APPOINTMENT REMINDER ---
        AppointmentRepository.init(context)
        val activeAppointments = AppointmentRepository.liveAppointments.value?.filter {
            !it.isDeletedByPatient && !it.isDeletedCompletely && it.status != "Cancelled"
        }

        val latestAppointment = activeAppointments?.firstOrNull()
        val dismissedReminderId = prefs.getString(KEY_DISMISSED_REMINDER, "")

        if (latestAppointment != null && latestAppointment.id != dismissedReminderId) {
            tvReminderHeader?.visibility = View.VISIBLE
            cardReminder?.visibility = View.VISIBLE
            tvReminderDate?.text = latestAppointment.dateTime
            tvReminderText?.text = "Reminder: Appointment with ${latestAppointment.doctorName} for ${latestAppointment.specialty} at ${latestAppointment.dateTime}."
        } else {
            tvReminderHeader?.visibility = View.GONE
            cardReminder?.visibility = View.GONE
        }

        // --- 2. REAL-TIME CLINIC CONTACT / OFFICE HOURS UPDATES ---
        val allDoctors = DoctorRepository.getAllDoctors(context)
        val latestDoctorUpdate = allDoctors.firstOrNull { it.nextAvailableTime.isNotEmpty() }

        val isUpdatesDismissed = prefs.getBoolean(KEY_DISMISSED_UPDATES, false)

        if (latestDoctorUpdate != null && !isUpdatesDismissed) {
            tvUpdatesHeader?.visibility = View.VISIBLE
            cardUpdates?.visibility = View.VISIBLE

            val currentTime = SimpleDateFormat("MMMM dd, yyyy  h:mm a", Locale.getDefault()).format(Date())
            tvUpdateDate?.text = currentTime
            tvUpdateText?.text = "Guiwan Medical Clinic has updated their contact information and office hours from 10:00 AM to 4:00 PM."
        } else {
            tvUpdatesHeader?.visibility = View.GONE
            cardUpdates?.visibility = View.GONE
        }

        checkEmptyState()

        // --- 3. DISMISS WITH CONFIRMATION DIALOG ---
        btnCloseReminder?.setOnClickListener {
            showDismissClueDialog(
                title = "Remove Appointment Reminder",
                message = "This will dismiss your active booking notification for ${latestAppointment?.doctorName ?: "your doctor"}. Are you sure you want to clear it?",
                onConfirm = {
                    latestAppointment?.let { appt ->
                        prefs.edit().putString(KEY_DISMISSED_REMINDER, appt.id).apply()
                    }
                    tvReminderHeader?.visibility = View.GONE
                    cardReminder?.visibility = View.GONE
                    checkEmptyState()
                    Toast.makeText(context, "Reminder notification dismissed", Toast.LENGTH_SHORT).show()
                }
            )
        }

        btnCloseUpdates?.setOnClickListener {
            showDismissClueDialog(
                title = "Remove Clinic Update",
                message = "This will dismiss the clinic contact and office hours announcement from your feed. Are you sure?",
                onConfirm = {
                    prefs.edit().putBoolean(KEY_DISMISSED_UPDATES, true).apply()
                    tvUpdatesHeader?.visibility = View.GONE
                    cardUpdates?.visibility = View.GONE
                    checkEmptyState()
                    Toast.makeText(context, "Clinic update notification dismissed", Toast.LENGTH_SHORT).show()
                }
            )
        }

        return view
    }

    private fun showDismissClueDialog(title: String, message: String, onConfirm: () -> Unit) {
        AlertDialog.Builder(requireContext())
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Remove") { dialog, _ ->
                onConfirm()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}