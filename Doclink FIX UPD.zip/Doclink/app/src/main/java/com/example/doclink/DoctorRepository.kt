package com.example.doclink

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object DoctorRepository {

    private const val PREFS_NAME = "doclink_doctor_prefs"
    private const val KEY_DOCTORS_LIST = "key_doctors_list"

    private val doctorList = mutableListOf<Doctor>()
    private var isInitialized = false

    private val defaultDoctors = listOf(
        Doctor(
            id = "doc1",
            name = "Dr. Jeo Dina Kya",
            specialty = "OB-GYN",
            address = "Guiwan Clinic",
            isAvailable = true,
            isActive = true,
            nextAvailableTime = "10:00 AM tomorrow",
            imageRes = R.drawable.ic_doctor_male,
            description1 = "Dr. Jeo Dina Kya is an OB-GYN dedicated to providing comprehensive and patient-centered medical care. He focuses on preventive medicine, early diagnosis, and appropriate treatment to help patients maintain and improve their overall health.",
            description2 = "He takes time to understand each patient's concerns and provides clear guidance based on their individual needs."
        ),
        Doctor(
            id = "doc2",
            name = "Dr. Chris Rivera",
            specialty = "Pediatrician",
            address = "Guiwan Clinic",
            isAvailable = false,
            isActive = true,
            nextAvailableTime = "Not Available",
            imageRes = R.drawable.ic_doctor_male,
            description1 = "Dr. Chris Rivera is a Pediatrician dedicated to providing comprehensive and patient-centered medical care for infants, children, and teens.",
            description2 = "He takes time to understand each patient's concerns and provides clear guidance based on their individual needs."
        ),
        Doctor(
            id = "doc3",
            name = "Dr. Mark Santiago",
            specialty = "Cardiologist",
            address = "Guiwan Clinic",
            isAvailable = true,
            isActive = true,
            nextAvailableTime = "10:00 AM tomorrow",
            imageRes = R.drawable.ic_doctor_male,
            description1 = "Dr. Mark Santiago is a Cardiologist dedicated to providing comprehensive and patient-centered heart care.",
            description2 = "He takes time to understand each patient's concerns and provides clear guidance based on their individual needs."
        ),
        Doctor(
            id = "doc4",
            name = "Dr. Sam Mendoza",
            specialty = "Dermatologist",
            address = "Guiwan Clinic",
            isAvailable = true,
            isActive = true,
            nextAvailableTime = "10:00 AM tomorrow",
            imageRes = R.drawable.ic_doctor_male,
            description1 = "Dr. Sam Mendoza is a Dermatologist dedicated to providing comprehensive and patient-centered skin care.",
            description2 = "He takes time to understand each patient's concerns and provides clear guidance based on their individual needs."
        )
    )

    fun init(context: Context, forceReload: Boolean = false) {
        if (isInitialized && !forceReload) return

        val sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = sharedPref.getString(KEY_DOCTORS_LIST, null)

        doctorList.clear()
        if (!json.isNullOrEmpty()) {
            val type = object : TypeToken<List<Doctor>>() {}.type
            val savedDoctors: List<Doctor> = Gson().fromJson(json, type)
            doctorList.addAll(savedDoctors)
        } else {
            doctorList.addAll(defaultDoctors)
            saveToPrefs(context)
        }

        isInitialized = true
    }

    // Only active doctors for Patient-facing views
    fun getActiveDoctors(context: Context? = null): List<Doctor> {
        context?.let { init(it, forceReload = true) }
        return doctorList.filter { it.isActive }
    }

    // All doctors (active + inactive) for Admin views
    fun getAllDoctors(context: Context? = null): List<Doctor> {
        context?.let { init(it, forceReload = true) }
        return doctorList
    }

    fun addDoctor(context: Context, doctor: Doctor) {
        init(context, forceReload = true)
        val newDoctor = doctor.copy(isActive = true)
        doctorList.add(0, newDoctor)
        saveToPrefs(context)
    }

    // Soft delete (hide from patient side)
    fun removeDoctor(context: Context, doctorId: String) {
        setDoctorActiveState(context, doctorId, false)
    }

    // Restore (show on patient side again)
    fun restoreDoctor(context: Context, doctorId: String) {
        setDoctorActiveState(context, doctorId, true)
    }

    private fun setDoctorActiveState(context: Context, doctorId: String, active: Boolean) {
        init(context, forceReload = true)
        val index = doctorList.indexOfFirst { it.id == doctorId }
        if (index != -1) {
            val oldDoc = doctorList[index]
            doctorList[index] = oldDoc.copy(isActive = active)
            saveToPrefs(context)
        }
    }

    fun updateDoctorAvailability(
        context: Context,
        doctorId: String,
        isAvailable: Boolean,
        newTime: String
    ) {
        init(context, forceReload = true)
        val index = doctorList.indexOfFirst { it.id == doctorId }
        if (index != -1) {
            val oldDoc = doctorList[index]
            val updatedDoc = oldDoc.copy(
                isAvailable = isAvailable,
                nextAvailableTime = if (isAvailable) newTime else "Not Available"
            )
            doctorList[index] = updatedDoc
            saveToPrefs(context)
        }
    }

    fun getDoctorCount(context: Context? = null): Int {
        context?.let { init(it, forceReload = true) }
        return getActiveDoctors().size
    }

    fun getDoctorById(context: Context? = null, id: String): Doctor? {
        context?.let { init(it, forceReload = true) }
        return doctorList.find { it.id == id }
    }

    private fun saveToPrefs(context: Context) {
        val sharedPref = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = Gson().toJson(doctorList)
        sharedPref.edit().putString(KEY_DOCTORS_LIST, json).apply()
    }
}