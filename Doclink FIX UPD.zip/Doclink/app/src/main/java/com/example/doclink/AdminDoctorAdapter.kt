package com.example.doclink

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdminDoctorAdapter(
    private var doctors: List<Doctor>,
    private val onEditClick: (Doctor) -> Unit,
    private val onRestoreClick: ((Doctor) -> Unit)? = null
) : RecyclerView.Adapter<AdminDoctorAdapter.AdminDoctorViewHolder>() {

    fun updateData(newList: List<Doctor>) {
        doctors = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdminDoctorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_admin_doctor, parent, false)
        return AdminDoctorViewHolder(view)
    }

    override fun onBindViewHolder(holder: AdminDoctorViewHolder, position: Int) {
        holder.bind(doctors[position], onEditClick, onRestoreClick)
    }

    override fun getItemCount(): Int = doctors.size

    class AdminDoctorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imgAvatar: ImageView = itemView.findViewById(R.id.imgDoctorAvatar)
        private val tvName: TextView = itemView.findViewById(R.id.tvDoctorName)
        private val tvSpecialty: TextView = itemView.findViewById(R.id.tvDoctorSpecialty)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvDoctorStatus)
        private val btnEdit: ImageView = itemView.findViewById(R.id.btnEditDoctor)

        fun bind(
            doctor: Doctor,
            onEditClick: (Doctor) -> Unit,
            onRestoreClick: ((Doctor) -> Unit)?
        ) {
            tvName.text = doctor.name
            tvSpecialty.text = doctor.specialty
            imgAvatar.setImageResource(doctor.imageRes)

            if (!doctor.isActive) {
                // Soft-deleted / Hidden state
                tvStatus.text = "Removed (Hidden)"
                tvStatus.setTextColor(Color.parseColor("#64748B")) // Slate Gray
                itemView.alpha = 0.55f
            } else if (doctor.isAvailable) {
                tvStatus.text = "Available"
                tvStatus.setTextColor(Color.parseColor("#22C55E")) // Green
                itemView.alpha = 1.0f
            } else {
                tvStatus.text = "Not Available"
                tvStatus.setTextColor(Color.parseColor("#EF4444")) // Red
                itemView.alpha = 1.0f
            }

            // Edit / Restore Action
            btnEdit.setOnClickListener {
                if (!doctor.isActive && onRestoreClick != null) {
                    onRestoreClick(doctor)
                } else {
                    onEditClick(doctor)
                }
            }

            // Also allow tapping the whole row for inactive doctors to bring up the restore prompt
            if (!doctor.isActive) {
                itemView.setOnClickListener {
                    onRestoreClick?.invoke(doctor)
                }
            } else {
                itemView.setOnClickListener(null)
            }
        }
    }
}