package com.example.doclink

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.imageview.ShapeableImageView

class DoctorAdapter(
    private var doctorList: List<Doctor>,
    private val onItemClick: ((Doctor) -> Unit)? = null
) : RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder>() {

    // Filter out inactive/removed doctors automatically
    private var fullDoctorList = ArrayList(doctorList.filter { it.isActive })

    init {
        doctorList = doctorList.filter { it.isActive }
    }

    class DoctorViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgDoctor: ShapeableImageView = itemView.findViewById(R.id.imgDoctorList)
        val tvName: TextView = itemView.findViewById(R.id.tvDoctorListName)
        val tvSpecialty: TextView = itemView.findViewById(R.id.tvDoctorListSpecialty)
        val tvAddress: TextView = itemView.findViewById(R.id.tvDoctorListAddress)
        val tvNextAvailableLabel: TextView? = itemView.findViewById(R.id.tvNextAvailableLabel)
        val tvNextAvailableTime: TextView = itemView.findViewById(R.id.tvNextAvailableTime)
        val btnBook: AppCompatButton = itemView.findViewById(R.id.btnBookNowList)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_doctor_card, parent, false)
        return DoctorViewHolder(view)
    }

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val doctor = doctorList[position]
        holder.tvName.text = doctor.name
        holder.tvSpecialty.text = doctor.specialty
        holder.tvAddress.text = "Address: ${doctor.address}"
        holder.imgDoctor.setImageResource(doctor.imageRes)

        fun openDoctorDetails() {
            val currentPosition = holder.bindingAdapterPosition
            if (currentPosition != RecyclerView.NO_POSITION) {
                val currentDoctor = doctorList[currentPosition]

                if (!currentDoctor.isAvailable || !currentDoctor.isActive) return

                onItemClick?.invoke(currentDoctor)

                val intent = Intent(holder.itemView.context, DoctorDetailsActivity::class.java).apply {
                    putExtra("DOCTOR_ID", currentDoctor.id)
                    putExtra("EXTRA_DOCTOR", currentDoctor)
                    addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                }
                holder.itemView.context.startActivity(intent)
            }
        }

        if (doctor.isAvailable && doctor.isActive) {
            holder.tvNextAvailableLabel?.visibility = View.VISIBLE
            holder.tvNextAvailableLabel?.text = "Next Available"

            val cleanTime = doctor.nextAvailableTime
                .replace("Next Available:", "", ignoreCase = true)
                .trim()

            holder.tvNextAvailableTime.text = if (cleanTime.isNotEmpty()) cleanTime else "10:00 AM tomorrow"
            holder.tvNextAvailableTime.setTextColor(Color.parseColor("#94A3B8"))

            holder.btnBook.text = "Book Appointment"
            holder.btnBook.isEnabled = true
            holder.itemView.isEnabled = true
            holder.itemView.alpha = 1.0f

            holder.btnBook.setOnClickListener { openDoctorDetails() }
            holder.itemView.setOnClickListener { openDoctorDetails() }
        } else {
            holder.tvNextAvailableLabel?.visibility = View.GONE

            holder.tvNextAvailableTime.text = "Status: Not Available"
            holder.tvNextAvailableTime.setTextColor(Color.parseColor("#EF4444"))

            holder.btnBook.text = "Not Available"
            holder.btnBook.isEnabled = false
            holder.itemView.isEnabled = false
            holder.itemView.alpha = 0.55f

            holder.btnBook.setOnClickListener(null)
            holder.itemView.setOnClickListener(null)
        }
    }

    override fun getItemCount(): Int = doctorList.size

    fun updateList(newList: List<Doctor>) {
        val activeOnly = newList.filter { it.isActive }
        doctorList = activeOnly
        fullDoctorList = ArrayList(activeOnly)
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        val tokens = extractSearchTokens(query)

        doctorList = if (tokens.isEmpty()) {
            fullDoctorList
        } else {
            fullDoctorList.filter { doctor ->
                val targetText = sanitizeText("${doctor.name} ${doctor.specialty} ${doctor.address}")
                tokens.all { token -> targetText.contains(token) }
            }
        }
        notifyDataSetChanged()
    }

    private fun extractSearchTokens(text: String): List<String> {
        val cleanText = sanitizeText(text)
        if (cleanText.isEmpty()) return emptyList()

        val tokens = cleanText.split("\\s+".toRegex()).filter { it.isNotEmpty() }
        if (tokens.size == 1 && tokens[0] == "dr") {
            return emptyList()
        }
        return tokens.filter { it != "dr" }
    }

    private fun sanitizeText(text: String): String {
        return text.lowercase()
            .replace(".", "")
            .replace(",", "")
            .trim()
    }
}