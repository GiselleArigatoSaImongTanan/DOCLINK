package com.example.doclink

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.doclink.databinding.ActivityMainPatientBinding

class MainPatientActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainPatientBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)

        binding = ActivityMainPatientBinding.inflate(layoutInflater)
        setContentView(binding.root)

        handleIntent(intent, savedInstanceState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent, null)
    }

    private fun handleIntent(intent: Intent?, savedInstanceState: Bundle?) {
        val targetTab = intent?.getStringExtra("OPEN_TAB")

        when (targetTab) {
            "APPOINTMENT" -> switchFragment(MyAppointmentsFragment(), NavigationUtils.NavTab.APPOINTMENT)
            "NOTIFICATION" -> switchFragment(NotificationsFragment(), NavigationUtils.NavTab.NOTIFICATION)
            "PROFILE" -> switchFragment(ProfileFragment(), NavigationUtils.NavTab.PROFILE)
            else -> {
                if (savedInstanceState == null) {
                    switchFragment(PatientHomeFragment(), NavigationUtils.NavTab.HOME)
                }
            }
        }
    }

    fun switchFragment(fragment: Fragment, tab: NavigationUtils.NavTab) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()

        NavigationUtils.setupBottomNavigation(this, tab)
    }
}