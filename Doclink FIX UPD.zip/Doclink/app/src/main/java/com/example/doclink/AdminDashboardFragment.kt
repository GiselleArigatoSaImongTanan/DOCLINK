package com.example.doclink

import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.doclink.databinding.FragmentAdminDashboardBinding
import com.google.android.material.imageview.ShapeableImageView
import com.google.android.material.shape.CornerFamily
import com.google.android.material.shape.ShapeAppearanceModel

class AdminDashboardFragment : Fragment() {

    private var _binding: FragmentAdminDashboardBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAdminDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        observeLiveDashboardData()
    }

    override fun onResume() {
        super.onResume()
        binding.tvDoctorCount.text = DoctorRepository.getDoctorCount().toString()

        activity?.let {
            NavigationUtils.setupAdminNavigation(it, NavigationUtils.AdminTab.HOME)
        }
    }

    private fun observeLiveDashboardData() {
        binding.tvDoctorCount.text = DoctorRepository.getDoctorCount().toString()

        AppointmentRepository.liveAppointments.observe(viewLifecycleOwner) { allAppointments ->
            val activeAppointments = allAppointments.filter { !it.isDeletedCompletely }

            val acceptedList = activeAppointments.filter {
                it.status.equals("Accepted", ignoreCase = true) || it.status.equals("Confirmed", ignoreCase = true)
            }

            binding.tvAppointmentCount.text = acceptedList.size.toString()

            val uniquePatients = acceptedList.map { it.patientName }.distinct()
            binding.tvPatientCount.text = uniquePatients.size.toString()

            binding.containerLatestBookings.removeAllViews()

            if (acceptedList.isEmpty()) {
                binding.tvEmptyBookings.visibility = View.VISIBLE
                binding.containerLatestBookings.visibility = View.GONE
            } else {
                binding.tvEmptyBookings.visibility = View.GONE
                binding.containerLatestBookings.visibility = View.VISIBLE

                for (item in acceptedList) {
                    addBookingRow(item)
                }
            }
        }
    }

    private fun addBookingRow(item: AppointmentItem) {
        val context = requireContext()

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(40, 32, 40, 32)
        }

        val avatar = ShapeableImageView(context).apply {
            layoutParams = LinearLayout.LayoutParams(110, 110)
            setImageResource(R.drawable.user_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            shapeAppearanceModel = ShapeAppearanceModel.builder()
                .setAllCorners(CornerFamily.ROUNDED, 100f)
                .build()
        }

        val detailsLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = 32
            }
        }

        val tvName = TextView(context).apply {
            text = item.patientName
            textSize = 16f
            setTextColor(Color.parseColor("#1E293B"))
            setTypeface(null, Typeface.BOLD)
        }

        val tvDate = TextView(context).apply {
            text = "Booking on ${item.dateTime}"
            textSize = 13f
            setTextColor(Color.parseColor("#94A3B8"))
        }

        detailsLayout.addView(tvName)
        detailsLayout.addView(tvDate)

        val tvStatus = TextView(context).apply {
            text = "Confirmed"
            textSize = 14f
            setTextColor(Color.parseColor("#22C55E"))
            setTypeface(null, Typeface.BOLD)
        }

        row.addView(avatar)
        row.addView(detailsLayout)
        row.addView(tvStatus)

        binding.containerLatestBookings.addView(row)

        val divider = View(context).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            setBackgroundColor(Color.parseColor("#F1F5F9"))
        }
        binding.containerLatestBookings.addView(divider)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}