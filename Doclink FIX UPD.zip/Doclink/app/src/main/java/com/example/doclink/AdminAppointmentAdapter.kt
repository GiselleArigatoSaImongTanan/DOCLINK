package com.example.doclink

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AdminAppointmentAdapter(
    private val appointments: MutableList<AppointmentItem>,
    private val onAcceptClick: (AppointmentItem) -> Unit,
    private val onDeleteClick: (AppointmentItem) -> Unit
) : RecyclerView.Adapter<AdminAppointmentAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val ivPatientImage: ImageView = view.findViewById(R.id.ivPatientImage)
        val tvPatientName: TextView = view.findViewById(R.id.tvPatientName)
        val tvDoctorName: TextView = view.findViewById(R.id.tvDoctorName)
        val tvSpecialty: TextView = view.findViewById(R.id.tvSpecialty)
        val tvDateTime: TextView = view.findViewById(R.id.tvDateTime)
        val tvStatus: TextView = view.findViewById(R.id.tvStatus)
        val btnAccept: Button = view.findViewById(R.id.btnAccept)
        val btnDelete: ImageView? = view.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_appointment, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = appointments[position]

        // Display actual registered patient name
        holder.tvPatientName.text = if (item.patientName.isNotBlank()) item.patientName else "Registered Patient"
        holder.tvDoctorName.text = "Doctor: ${item.doctorName}"
        holder.tvSpecialty.text = item.specialty
        holder.tvDateTime.text = "Date & Time: ${item.dateTime}"

        if (item.patientImageRes != 0) {
            holder.ivPatientImage.setImageResource(item.patientImageRes)
        } else {
            holder.ivPatientImage.setImageResource(R.drawable.user_avatar)
        }

        val isAccepted = item.status.equals("Accepted", ignoreCase = true) ||
                item.status.equals("Confirmed", ignoreCase = true)

        if (isAccepted) {
            holder.tvStatus.text = "Accepted"
            holder.tvStatus.setTextColor(Color.parseColor("#22C55E")) // Bright Green
            holder.btnAccept.visibility = View.GONE
        } else {
            holder.tvStatus.text = "Pending"
            holder.tvStatus.setTextColor(Color.parseColor("#EF4444")) // Red
            holder.btnAccept.visibility = View.VISIBLE
            holder.btnAccept.setOnClickListener {
                onAcceptClick(item)
            }
        }

        holder.btnDelete?.let { btn ->
            btn.visibility = View.VISIBLE
            btn.setColorFilter(Color.parseColor("#94A3B8"))
            btn.setOnClickListener {
                btn.setColorFilter(Color.parseColor("#EF4444"))
                btn.postDelayed({
                    val pos = holder.bindingAdapterPosition
                    if (pos != RecyclerView.NO_POSITION && pos < appointments.size) {
                        onDeleteClick(appointments[pos])
                    }
                }, 150)
            }
        }
    }

    override fun getItemCount() = appointments.size
}