package com.example.doclink

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.doclink.databinding.ActivityDoctorDetailsBinding

class DoctorDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDoctorDetailsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)

        binding = ActivityDoctorDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupBackPressHandler()

        val doctorFromIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getSerializableExtra("EXTRA_DOCTOR", Doctor::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getSerializableExtra("EXTRA_DOCTOR") as? Doctor
        }

        val doctorId = doctorFromIntent?.id ?: intent.getStringExtra("DOCTOR_ID") ?: "doc1"

        // Pass Context to load accurate persistent state from SharedPreferences
        val doctor = DoctorRepository.getDoctorById(this, doctorId)
            ?: doctorFromIntent
            ?: DoctorRepository.getAllDoctors(this).firstOrNull()
            ?: Doctor(
                id = "doc1",
                name = "Dr. Jeo Dina Kya",
                specialty = "OB-GYN",
                address = "General Hospital",
                isAvailable = true,
                nextAvailableTime = "09:00 AM tomorrow",
                imageRes = R.drawable.ic_doctor_male,
                description1 = "Expert in obstetrics and gynecology.",
                description2 = ""
            )

        // Binding image and texts
        val imageResource: Int = if (doctor.imageRes != 0) doctor.imageRes else R.drawable.ic_doctor_male
        binding.imgDoctorDetails.setImageResource(imageResource)

        binding.tvDoctorNameDetails.text = doctor.name
        binding.tvDoctorSpecialtyDetails.text = doctor.specialty
        binding.tvDoctorAddressDetails.text = "Address: ${doctor.address}"
        binding.tvDoctorDescription1.text = doctor.description1

        if (doctor.description2.isNotEmpty()) {
            binding.tvDoctorDescription2.visibility = View.VISIBLE
            binding.tvDoctorDescription2.text = doctor.description2
        } else {
            binding.tvDoctorDescription2.visibility = View.GONE
        }

        // Lock button and show warning if Doctor is marked Not Available
        if (doctor.isAvailable) {
            binding.btnBookAppointmentSubmit.text = "Book Appointment"
            binding.btnBookAppointmentSubmit.isEnabled = true
            binding.btnBookAppointmentSubmit.alpha = 1.0f

            binding.btnBookAppointmentSubmit.setOnClickListener {
                val intent = Intent(this, BookAppointmentActivity::class.java).apply {
                    putExtra("DOCTOR_ID", doctor.id)
                    putExtra("DOCTOR_NAME", doctor.name)
                    putExtra("DOCTOR_SPECIALTY", doctor.specialty)
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
                }
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        } else {
            binding.btnBookAppointmentSubmit.text = "Doctor Not Available"
            binding.btnBookAppointmentSubmit.isEnabled = false
            binding.btnBookAppointmentSubmit.alpha = 0.55f

            binding.btnBookAppointmentSubmit.setOnClickListener {
                Toast.makeText(this, "${doctor.name} is currently not available for booking.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupBackPressHandler() {
        // Delegate back button click directly toBackPressedDispatcher
        binding.btnBackDetails.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
                overridePendingTransition(0, 0)
            }
        })
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}