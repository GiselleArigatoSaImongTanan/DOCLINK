package com.example.doclink

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)

        // Initialize DoctorRepository from persistent SharedPreferences on app startup
        DoctorRepository.init(this)

        setContentView(R.layout.activity_main)

        val btnBook = findViewById<Button>(R.id.btnBook)
        val btnHelp = findViewById<ImageButton>(R.id.btnHelp)

        btnBook.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            startActivity(intent)
            overridePendingTransition(0, 0)
        }

        btnHelp.setOnClickListener {
            val spinAnim = AnimationUtils.loadAnimation(this, R.anim.help_icon_spin)
            btnHelp.startAnimation(spinAnim)
            showHelpDialog()
        }
    }

    private fun showHelpDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_help_info, null)

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val cardDialog = dialogView.findViewById<CardView>(R.id.cardDialog)
        val btnClose = dialogView.findViewById<FloatingActionButton>(R.id.btnClose)

        btnClose.setOnClickListener {
            val popOutAnim = AnimationUtils.loadAnimation(this, R.anim.dialog_pop_out)
            cardDialog.startAnimation(popOutAnim)

            cardDialog.postDelayed({
                dialog.dismiss()
            }, 120)
        }

        dialog.show()
    }
}