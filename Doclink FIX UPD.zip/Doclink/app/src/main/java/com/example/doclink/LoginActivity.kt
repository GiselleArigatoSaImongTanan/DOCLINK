package com.example.doclink

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class LoginActivity : AppCompatActivity() {

    private var isPatientSelected = true

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        setupBackPressHandler()

        val toggleContainer = findViewById<FrameLayout>(R.id.toggleContainer)
        val viewIndicator = findViewById<View>(R.id.viewIndicator)
        val btnPatient = findViewById<TextView>(R.id.btnPatient)
        val btnAdmin = findViewById<TextView>(R.id.btnAdmin)
        val tvWelcomeTitle = findViewById<TextView>(R.id.tvWelcomeTitle)
        val tvWelcomeSub = findViewById<TextView>(R.id.tvWelcomeSub)
        val tvRegister = findViewById<TextView>(R.id.tvRegister)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        val etUsername = findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)

        tvRegister.background = null

        toggleContainer.post {
            val totalWidth = toggleContainer.width
            val halfWidth = totalWidth / 2

            val params = viewIndicator.layoutParams
            params.width = halfWidth - 6
            viewIndicator.layoutParams = params
        }

        btnPatient.setOnClickListener {
            if (!isPatientSelected) {
                isPatientSelected = true
                animateToggle(viewIndicator, 0f)

                btnPatient.setTextColor(Color.WHITE)
                btnAdmin.setTextColor(Color.parseColor("#0F2552"))

                tvWelcomeTitle.text = "Hello, Welcome!"
                tvWelcomeSub.text = "Log in to your account to manage your healthcare appointments."
                tvRegister.visibility = View.VISIBLE
            }
        }

        btnAdmin.setOnClickListener {
            if (isPatientSelected) {
                isPatientSelected = false
                val targetX = (toggleContainer.width / 2f) - 3f
                animateToggle(viewIndicator, targetX)

                btnAdmin.setTextColor(Color.WHITE)
                btnPatient.setTextColor(Color.parseColor("#0F2552"))

                tvWelcomeTitle.text = "Hello, Admin!"
                tvWelcomeSub.text = "Log in to manage appointments and keep your healthcare services organized."
                tvRegister.visibility = View.GONE
            }
        }

        tvRegister.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> (v as TextView).setTextColor(Color.parseColor("#0F2552"))
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> (v as TextView).setTextColor(Color.parseColor("#3B82F6"))
            }
            false
        }

        tvRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            startActivity(intent)
            overridePendingTransition(0, 0)
        }

        btnLogin.setOnClickListener {
            val usernameInput = etUsername.text.toString().trim()
            val passwordInput = etPassword.text.toString().trim()

            var hasError = false
            if (usernameInput.isEmpty()) {
                etUsername.error = "Please enter your username or email"
                hasError = true
            }
            if (passwordInput.isEmpty()) {
                etPassword.error = "Please enter your password"
                hasError = true
            }

            if (hasError) return@setOnClickListener

            if (isPatientSelected) {
                val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
                val inputLower = usernameInput.lowercase()

                val resolvedUsername = sharedPref.getString("EMAIL_MAP_$inputLower", usernameInput) ?: usernameInput
                val userKey = resolvedUsername.lowercase()

                val savedPass = sharedPref.getString("USER_${userKey}_PASS", null)
                val actualUsername = sharedPref.getString("USER_${userKey}_USERNAME", resolvedUsername) ?: resolvedUsername

                val isValidUser = savedPass != null && passwordInput == savedPass
                val isValidDemoPatient = usernameInput.equals("patient", ignoreCase = true) && passwordInput == "123456"

                if (isValidUser || isValidDemoPatient) {
                    val activeUser = if (isValidDemoPatient) "Patient" else actualUsername

                    with(sharedPref.edit()) {
                        putString("CURRENT_LOGGED_IN_USER", activeUser)
                        putString("REGISTERED_NAME", activeUser)
                        putString("USER_NAME", activeUser)
                        if (isValidDemoPatient && !sharedPref.contains("USER_patient_USERNAME")) {
                            putString("USER_patient_USERNAME", "Patient")
                            putString("USER_patient_EMAIL", "patient@doclink.com")
                            putString("USER_patient_CONTACT", "+63 900 0000 000")
                        }
                        apply()
                    }

                    val intent = Intent(this, MainPatientActivity::class.java).apply {
                        putExtra("USER_NAME", activeUser)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    finish()
                } else {
                    showErrorDialog("The input credentials are not registered. Please check your details or create a new account.")
                }
            } else {
                if (usernameInput == "admin" && passwordInput == "admin123") {
                    val intent = Intent(this, MainAdminActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    overridePendingTransition(0, 0)
                    finish()
                } else {
                    showErrorDialog("Invalid Admin Credentials!")
                }
            }
        }
    }

    private fun showErrorDialog(message: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(R.layout.dialog_error)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(true)

        val btnClose = dialog.findViewById<ImageView>(R.id.btnCloseDialog)
        val tvMessage = dialog.findViewById<TextView>(R.id.tvErrorMessage)

        tvMessage.text = message
        btnClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun animateToggle(view: View, toX: Float) {
        view.animate()
            .translationX(toX)
            .setDuration(200)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                finish()
                overridePendingTransition(0, 0)
            }
        })
    }
}