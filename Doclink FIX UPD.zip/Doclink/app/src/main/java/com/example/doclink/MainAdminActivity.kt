package com.example.doclink

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment

class MainAdminActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        overridePendingTransition(0, 0)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_admin)

        AppointmentRepository.init(this)
        setupBackPressHandler()

        // Admin Profile Header Click -> Show Logout Confirmation
        val layoutAdminHeader = findViewById<LinearLayout>(R.id.layoutAdminHeader)
        layoutAdminHeader?.setOnClickListener {
            showLogoutDialog()
        }

        if (savedInstanceState == null) {
            loadFragment(AdminDashboardFragment(), NavigationUtils.AdminTab.HOME)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun showLogoutDialog() {
        val dialog = AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out of the admin panel?")
            .setPositiveButton("OK", null)
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()

        val btnPositive = dialog.getButton(AlertDialog.BUTTON_POSITIVE)
        val btnNegative = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)

        val defaultBlue = Color.parseColor("#0284C7")
        val defaultGray = Color.parseColor("#64748B")
        val navyBlue = Color.parseColor("#000080")

        // 1. Remove all Material highlights, shadows, circular clips, and animations
        listOfNotNull(btnPositive, btnNegative).forEach { button ->
            button.background = ColorDrawable(Color.TRANSPARENT)
            button.stateListAnimator = null
            button.elevation = 0f
        }

        // 2. Set initial text colors
        btnPositive?.setTextColor(defaultBlue)
        btnNegative?.setTextColor(defaultGray)

        // 3. Positive ("OK") Touch Listener -> Only text color changes to Navy Blue
        btnPositive?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    btnPositive.setTextColor(navyBlue)
                }
                MotionEvent.ACTION_UP -> {
                    btnPositive.setTextColor(defaultBlue)
                    dialog.dismiss()
                    performLogout()
                }
                MotionEvent.ACTION_CANCEL -> {
                    btnPositive.setTextColor(defaultBlue)
                }
            }
            true
        }

        // 4. Negative ("Cancel") Touch Listener -> Only text color changes to Navy Blue
        btnNegative?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    btnNegative.setTextColor(navyBlue)
                }
                MotionEvent.ACTION_UP -> {
                    btnNegative.setTextColor(defaultGray)
                    dialog.dismiss()
                }
                MotionEvent.ACTION_CANCEL -> {
                    btnNegative.setTextColor(defaultGray)
                }
            }
            true
        }
    }

    private fun performLogout() {
        val intent = Intent(this, LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        overridePendingTransition(0, 0)
        finish()
    }

    fun loadFragment(fragment: Fragment, tab: NavigationUtils.AdminTab? = null) {
        val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)

        if (currentFragment != null && currentFragment::class == fragment::class) {
            return
        }

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()

        tab?.let { updateActiveTab(it) }
    }

    fun updateActiveTab(tab: NavigationUtils.AdminTab) {
        NavigationUtils.setupAdminNavigation(this, tab)
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val currentFragment = supportFragmentManager.findFragmentById(R.id.fragment_container)

                if (currentFragment !is AdminDashboardFragment) {
                    loadFragment(AdminDashboardFragment(), NavigationUtils.AdminTab.HOME)
                } else {
                    showLogoutDialog()
                }
            }
        })
    }
}