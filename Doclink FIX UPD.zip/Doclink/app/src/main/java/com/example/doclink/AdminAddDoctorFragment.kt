package com.example.doclink

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import java.util.UUID

class AdminAddDoctorFragment : Fragment() {

    private lateinit var spinnerSpecialty: Spinner
    private lateinit var spinnerExperience: Spinner
    private lateinit var etDoctorName: EditText
    private lateinit var etDoctorAddress: EditText
    private lateinit var etAboutDoctor: EditText
    private lateinit var btnAddDoctor: Button

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_admin_add_doctor, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        spinnerSpecialty = view.findViewById(R.id.spinnerSpecialty)
        spinnerExperience = view.findViewById(R.id.spinnerExperience)
        etDoctorName = view.findViewById(R.id.etDoctorName)
        etDoctorAddress = view.findViewById(R.id.etDoctorAddress)
        etAboutDoctor = view.findViewById(R.id.etAboutDoctor)
        btnAddDoctor = view.findViewById(R.id.btnAddDoctor)

        setupSpinners()

        btnAddDoctor.setOnClickListener {
            val nameRaw = etDoctorName.text.toString().trim()
            val addressRaw = etDoctorAddress.text.toString().trim()
            val aboutRaw = etAboutDoctor.text.toString().trim()
            val specialty = spinnerSpecialty.selectedItem.toString()
            val experience = spinnerExperience.selectedItem.toString()

            if (nameRaw.isEmpty()) {
                etDoctorName.error = "Please enter doctor's name"
                return@setOnClickListener
            }

            val formattedName = if (nameRaw.startsWith("Dr.", ignoreCase = true)) nameRaw else "Dr. $nameRaw"
            val formattedAddress = if (addressRaw.isNotEmpty()) addressRaw else "Guiwan Clinic"

            val primaryDesc = "$formattedName is a $specialty with $experience of clinical experience. $aboutRaw".trim()
            val secondaryDesc = "Dedicated to delivering comprehensive, patient-centered care and optimal medical guidance."

            val newDoctor = Doctor(
                id = UUID.randomUUID().toString(),
                name = formattedName,
                specialty = specialty,
                address = formattedAddress,
                isAvailable = true,
                isActive = true, // Default to visible for patients
                nextAvailableTime = "10:00 AM tomorrow",
                imageRes = R.drawable.ic_doctor_male,
                description1 = primaryDesc,
                description2 = secondaryDesc
            )

            // Persist new doctor in SharedPreferences repository
            DoctorRepository.addDoctor(requireContext(), newDoctor)

            Toast.makeText(requireContext(), "Doctor $formattedName added successfully!", Toast.LENGTH_SHORT).show()

            // Navigate to Doctor List Fragment inside host MainAdminActivity
            (activity as? MainAdminActivity)?.loadFragment(
                AdminDoctorListFragment(),
                NavigationUtils.AdminTab.DOCTOR_LIST
            )
        }
    }

    override fun onResume() {
        super.onResume()
        activity?.let {
            NavigationUtils.setupAdminNavigation(it, NavigationUtils.AdminTab.ADD_DOCTOR)
        }
    }

    private fun setupSpinners() {
        val specialties = arrayOf("General Physician", "OB-GYN", "Cardiologist", "Dermatologist", "Pediatrician")
        val experiences = arrayOf("1 year", "2 years", "3 years", "5+ years")

        val specialtyAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, specialties)
        val experienceAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, experiences)

        spinnerSpecialty.adapter = specialtyAdapter
        spinnerExperience.adapter = experienceAdapter
    }
}