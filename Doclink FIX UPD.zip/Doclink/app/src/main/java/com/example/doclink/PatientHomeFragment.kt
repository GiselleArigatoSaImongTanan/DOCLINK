package com.example.doclink

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.Fragment
import com.google.android.material.card.MaterialCardView

class PatientHomeFragment : Fragment() {

    private var isNavigatingToSearch = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_patient_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUserGreeting(view)
        setupFeaturedDoctors(view)
        setupPopularDoctors(view)
        setupSearchAndNavigation(view)
    }

    override fun onResume() {
        super.onResume()
        isNavigatingToSearch = false

        view?.let { root ->
            val etSearch = root.findViewById<EditText?>(R.id.etSearch)
            etSearch?.setText("")

            setupFeaturedDoctors(root)
            setupPopularDoctors(root)
        }
    }

    private fun setupUserGreeting(view: View) {
        val tvUserGreeting = view.findViewById<TextView?>(R.id.tvUserGreeting)
        val imgUserProfile = view.findViewById<ImageView?>(R.id.imgUserProfile)
        val context = requireContext()

        val sharedPref = context.getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        val savedName = sharedPref.getString("REGISTERED_NAME", "User")
        val userName = activity?.intent?.getStringExtra("USER_NAME") ?: savedName

        tvUserGreeting?.text = "Hello, $userName!"

        // Add red border clue on touch/click
        imgUserProfile?.let { avatar ->
            val defaultDrawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(0, Color.TRANSPARENT)
            }

            val activeRedDrawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(6, Color.parseColor("#EF4444")) // Red border clue
            }

            avatar.background = defaultDrawable

            avatar.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        avatar.background = activeRedDrawable
                        avatar.paddingFromEdge(4)
                    }
                    MotionEvent.ACTION_UP -> {
                        avatar.background = defaultDrawable
                        avatar.paddingFromEdge(0)

                        val mainActivity = activity as? MainPatientActivity
                        mainActivity?.switchFragment(ProfileFragment(), NavigationUtils.NavTab.PROFILE)
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        avatar.background = defaultDrawable
                        avatar.paddingFromEdge(0)
                    }
                }
                true
            }
        }
    }

    private fun View.paddingFromEdge(paddingDp: Int) {
        val density = resources.displayMetrics.density
        val px = (paddingDp * density).toInt()
        setPadding(px, px, px, px)
    }

    private fun setupSearchAndNavigation(view: View) {
        val etSearch = view.findViewById<EditText?>(R.id.etSearch)
        val btnClearSearch = view.findViewById<ImageView?>(R.id.btnClearSearch)
        val tvSeeAllFeatured = view.findViewById<TextView?>(R.id.tvSeeAllFeatured)

        btnClearSearch?.setOnClickListener {
            etSearch?.setText("")
        }

        etSearch?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()

                if (query.isNotEmpty() && !isNavigatingToSearch) {
                    isNavigatingToSearch = true
                    openDoctorsSearchScreenFast(query)
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        tvSeeAllFeatured?.setOnClickListener { openDoctorsSearchScreenFast("") }
    }

    private fun openDoctorsSearchScreenFast(query: String) {
        val intent = Intent(requireContext(), DoctorsActivity::class.java).apply {
            putExtra("EXTRA_SEARCH_QUERY", query)
            addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        startActivity(intent)
        requireActivity().overridePendingTransition(0, 0)
    }

    private val applyHoverEffect = View.OnHoverListener { view, event ->
        when (event.action) {
            MotionEvent.ACTION_HOVER_ENTER -> {
                view.isHovered = true
                true
            }
            MotionEvent.ACTION_HOVER_EXIT -> {
                view.isHovered = false
                true
            }
            else -> false
        }
    }

    private fun setupFeaturedDoctors(view: View) {
        val context = requireContext()
        // Only fetch active (non-removed) doctors for patient views
        val activeDoctors = DoctorRepository.getActiveDoctors(context)
        val cardIds = listOf(R.id.cardDoctor1, R.id.cardDoctor2, R.id.cardDoctor3, R.id.cardDoctor4)

        cardIds.forEachIndexed { index, layoutId ->
            val card = view.findViewById<View?>(layoutId)
            if (card != null) {
                if (index < activeDoctors.size) {
                    val doctor = activeDoctors[index]
                    card.visibility = View.VISIBLE
                    card.setOnHoverListener(applyHoverEffect)

                    card.findViewById<TextView?>(R.id.tvDoctorName)?.text = doctor.name
                    card.findViewById<TextView?>(R.id.tvDoctorSpecialty)?.text = doctor.specialty

                    val btnBookNow = card.findViewById<AppCompatButton?>(R.id.btnBookNow)

                    if (doctor.isAvailable) {
                        card.alpha = 1.0f
                        btnBookNow?.text = "Book Now"
                        btnBookNow?.isEnabled = true

                        val openDetails = View.OnClickListener { openDoctorDetails(doctor.id) }
                        card.setOnClickListener(openDetails)
                        btnBookNow?.setOnClickListener(openDetails)
                    } else {
                        card.alpha = 0.55f
                        btnBookNow?.text = "Not Available"
                        btnBookNow?.isEnabled = false

                        val showUnavailableToast = View.OnClickListener {
                            Toast.makeText(context, "${doctor.name} is currently not available for booking.", Toast.LENGTH_SHORT).show()
                        }
                        card.setOnClickListener(showUnavailableToast)
                        btnBookNow?.setOnClickListener(showUnavailableToast)
                    }
                } else {
                    card.visibility = View.GONE
                }
            }
        }
    }

    private fun setupPopularDoctors(view: View) {
        val context = requireContext()
        // Only fetch active (non-removed) doctors for patient views
        val activeDoctors = DoctorRepository.getActiveDoctors(context)

        val cardPopularJeo = view.findViewById<MaterialCardView?>(R.id.cardPopularJeo)
        val cardPopularChris = view.findViewById<MaterialCardView?>(R.id.cardPopularChris)

        cardPopularJeo?.setOnHoverListener(applyHoverEffect)
        cardPopularChris?.setOnHoverListener(applyHoverEffect)

        if (activeDoctors.isNotEmpty()) {
            val doctor1 = activeDoctors[0]
            cardPopularJeo?.visibility = View.VISIBLE
            bindPopularDoctorCard(cardPopularJeo, doctor1, R.id.tvPopularName1, R.id.tvPopularSpecialty1, R.id.tvPopularStatus1)
        } else {
            cardPopularJeo?.visibility = View.GONE
        }

        if (activeDoctors.size > 1) {
            val doctor2 = activeDoctors[1]
            cardPopularChris?.visibility = View.VISIBLE
            bindPopularDoctorCard(cardPopularChris, doctor2, R.id.tvPopularName2, R.id.tvPopularSpecialty2, R.id.tvPopularStatus2)
        } else {
            cardPopularChris?.visibility = View.GONE
        }
    }

    private fun bindPopularDoctorCard(
        card: MaterialCardView?,
        doctor: Doctor,
        nameId: Int,
        specialtyId: Int,
        statusId: Int
    ) {
        if (card == null) return

        card.findViewById<TextView?>(nameId)?.text = doctor.name
        card.findViewById<TextView?>(specialtyId)?.text = doctor.specialty

        val tvStatus = card.findViewById<TextView?>(statusId)

        if (doctor.isAvailable) {
            card.alpha = 1.0f
            tvStatus?.text = "Available"
            tvStatus?.setTextColor(Color.parseColor("#22C55E"))

            card.setOnClickListener {
                openDoctorDetails(doctor.id)
            }
        } else {
            card.alpha = 0.55f
            tvStatus?.text = "Not Available"
            tvStatus?.setTextColor(Color.parseColor("#EF4444"))

            card.setOnClickListener {
                Toast.makeText(requireContext(), "${doctor.name} is currently not available for booking.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openDoctorDetails(doctorId: String) {
        val context = requireContext()
        val doctor = DoctorRepository.getDoctorById(context, doctorId)

        if (doctor != null && (!doctor.isAvailable || !doctor.isActive)) {
            Toast.makeText(context, "${doctor.name} is currently not available for booking.", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(context, DoctorDetailsActivity::class.java).apply {
            putExtra("DOCTOR_ID", doctorId)
            if (doctor != null) {
                putExtra("EXTRA_DOCTOR", doctor)
            }
            addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        }
        startActivity(intent)
        requireActivity().overridePendingTransition(0, 0)
    }
}